# EventManagement
i have created a event management website using html,css,javascript
click here for the project:https://snrou.github.io/EventManagement/
